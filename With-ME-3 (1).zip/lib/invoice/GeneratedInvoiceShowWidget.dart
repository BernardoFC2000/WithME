import 'package:flutter/material.dart';
import 'package:flutterapp/invoice/GeneratedDateINVOICEWidget.dart';
import 'package:flutterapp/invoice/GeneratedProductINVOICEWidget.dart';
import 'package:flutterapp/invoice/GeneratedIssuerINVOICEWidget.dart';
import 'package:flutterapp/invoice/GeneratedValueINVOICEWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedcategoriesscreenwidget/generated/GeneratedFavIconCATEGORIESWidget.dart';

class GeneratedInvoiceShowWidget extends StatefulWidget {
  @override
  _GeneratedInvoiceShowWidgetState createState() => _GeneratedInvoiceShowWidgetState();
}

class _GeneratedInvoiceShowWidgetState extends State<GeneratedInvoiceShowWidget> {
  @override
  //Acesso ao invoice
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, '/GeneratedWortenInvoiceScreenWidget'),
      child: Container(
        width: 355.0056457519531,
        height: 75.0,
        child: Stack(fit: StackFit.expand, alignment: Alignment.center, overflow: Overflow.visible, children: [
          Positioned(
            left: 2.0,
            top: 0.0,
            right: null,
            bottom: null,
            width: 70.0,
            height: 22.0,
            child: GeneratedDateINVOICEWidget(),
          ),
          Positioned(
              left: -8.0,
              top: 23.0,
              right: null,
              bottom: null,
              width: 369.01,
              height: 0.5,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.0),
                child: Container(
                  height: 1.0,
                  width: 130.0,
                  color: Color.fromARGB(255, 0, 0, 0),
                ),
              )),
          Positioned(
            left: 9.0,
            top: 29.0,
            right: null,
            bottom: null,
            width: 249.0,
            height: 22.0,
            child: GeneratedProductINVOICEWidget(),
          ),
          Positioned(
            left: 9.0,
            top: 49.0,
            right: null,
            bottom: null,
            width: 249.0,
            height: 17.0,
            child: GeneratedIssuerINVOICEWidget(),
          ),
          Positioned(
            left: 335.0,
            top: 49.0,
            right: null,
            bottom: null,
            width: 12.0,
            height: 12.0,
            child: GeneratedFavIconCATEGORIESWidget(),
          ),
          Positioned(
            left: 283.0,
            top: 29.0,
            right: null,
            bottom: null,
            width: 66.0,
            height: 19.0,
            child: GeneratedValueINVOICEWidget(),
          ),
        ]),
      ),
    );
  }
}
