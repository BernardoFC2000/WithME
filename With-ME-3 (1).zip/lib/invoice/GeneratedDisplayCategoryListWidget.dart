import 'package:flutterapp/invoice/GeneratedInvoiceShowWidget.dart';
import 'package:flutter/material.dart';
import 'package:flutterapp/backend/Instance.dart';
import 'package:flutterapp/backend/GeneratedListInvoiceWidget.dart';
//import 'package:flutterapp/backend/GeneratedInvoiceClassWidget.dart';
import 'package:flutterapp/invoice/GeneratedDateINVOICEWidget.dart';
import 'package:flutterapp/invoice/GeneratedProductINVOICEWidget.dart';
import 'package:flutterapp/invoice/GeneratedIssuerINVOICEWidget.dart';
import 'package:flutterapp/invoice/GeneratedValueINVOICEWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedcategoriesscreenwidget/generated/GeneratedFavIconCATEGORIESWidget.dart';
import 'package:flutterapp/backend/InvoiceModel.dart';
import 'package:flutterapp/backend/InvoiceList.dart';
import 'package:flutterapp/backend/database.dart';

class GeneratedDisplayListWidget extends StatefulWidget {
  @override
  _GeneratedDisplayListWidgetState createState() => _GeneratedDisplayListWidgetState();
}

class _GeneratedDisplayListWidgetState extends State<GeneratedDisplayListWidget> {
  List<Invoice> invoiceList = [
    Invoice(
      issuer: "5015007930-IST",
      invoiceNumber: 3210062997,
      product: "Propinas",
      date: "2021-11-23",
      value: 630.0,
      warrantyTime: 0,
      category: "Education",
    ),
    Invoice(
      issuer: "5130046909-197-Farmacia",
      invoiceNumber: 62990,
      product: "Benuron",
      date: "2021-11-07",
      value: 9.99,
      warrantyTime: 0,
      category: "Health",
    ),
    Invoice(
      issuer: "505189119-Reparacao de automoveis",
      invoiceNumber: 2321186,
      product: "Pecas automoveis",
      date: "2021-12-29",
      value: 16.47,
      warrantyTime: 2,
      category: "Automobiles",
    ),
    Invoice(
      issuer: "508793319-Clinicas",
      invoiceNumber: 61061632,
      product: "Corte de Cabelo",
      date: "2021-11-09",
      value: 35.0,
      warrantyTime: 0,
      category: "HairDresser",
    ),
    Invoice(
      issuer: "503311332-EMEL",
      invoiceNumber: 61061632,
      product: "Multa",
      date: "2021-12-16",
      value: 120.0,
      warrantyTime: 0,
      category: "Family",
    ),
  ];

  //Acesso à lista da categoria
  @override
  Widget build(BuildContext context) {
    invoiceList
      ..sort((a, b) {
        //sorting in descending order
        return DateTime.parse(b.date).compareTo(DateTime.parse(a.date));
      });
    return Container(
      width: 355.0056457519531,
      height: 75.0,
      child: Stack(fit: StackFit.expand, alignment: Alignment.center, overflow: Overflow.visible, children: [
        ListView.builder(
            itemCount: invoiceList.length, //Instance.getInstance().invoices["MyInvoices"].length,
            itemBuilder: (BuildContext context, int index) {
              return Positioned(
                left: 10.0,
                top: 187 + index * 104.0,
                right: null,
                bottom: null,
                width: 355.0056457519531,
                height: 75.0,
                child: _GeneratedInvoiceShowWidget(invoiceList[index], context),
              );
            })
      ]),
    );
  }

  Widget _GeneratedInvoiceShowWidget(Invoice invoice, BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, '/GeneratedWortenInvoiceScreenWidget'),
      child: Container(
        width: 355.0056457519531,
        height: 75.0,
        child: Stack(fit: StackFit.expand, alignment: Alignment.center, overflow: Overflow.visible, children: [
          Positioned(
            left: 2.0,
            top: 0.0,
            right: null,
            bottom: null,
            width: 1000.0,
            height: 22.0,
            child: _GeneratedDateINVOICEWidget(invoice, context),
          ),
          Positioned(
              left: -8.0,
              top: 23.0,
              right: null,
              bottom: null,
              width: 369.01,
              height: 0.5,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.0),
                child: Container(
                  height: 1.0,
                  width: 130.0,
                  color: Color.fromARGB(255, 0, 0, 0),
                ),
              )),
          Positioned(
            left: 9.0,
            top: 29.0,
            right: null,
            bottom: null,
            width: 249.0,
            height: 22.0,
            child: _GeneratedProductINVOICEWidget(invoice, context),
          ),
          Positioned(
            left: 9.0,
            top: 49.0,
            right: null,
            bottom: null,
            width: 249.0,
            height: 17.0,
            child: _GeneratedIssuerINVOICEWidget(invoice, context),
          ),
          Positioned(
            left: 335.0,
            top: 49.0,
            right: null,
            bottom: null,
            width: 12.0,
            height: 12.0,
            child: GeneratedFavIconCATEGORIESWidget(),
          ),
          Positioned(
            left: 283.0,
            top: 29.0,
            right: null,
            bottom: null,
            width: 66.0,
            height: 19.0,
            child: _GeneratedValueINVOICEWidget(invoice, context),
          ),
        ]),
      ),
    );
  }

  Widget _GeneratedDateINVOICEWidget(Invoice invoice, BuildContext context) {
    return Text(
      invoice.date, //Instance.getInstance().invoices["MyInvoices"][index].date,
      overflow: TextOverflow.visible,
      textAlign: TextAlign.left,
      style: TextStyle(
        height: 1.171875,
        fontSize: 14.0,
        fontFamily: 'Montserrat',
        fontWeight: FontWeight.w600,
        color: Color.fromARGB(255, 42, 83, 193),

        /* letterSpacing: 0.0, */
      ),
    );
  }

  Widget _GeneratedProductINVOICEWidget(Invoice invoice, BuildContext context) {
    return Text(
      invoice.product, //Instance.getInstance().invoices["MyInvoices"][index].product,
      overflow: TextOverflow.visible,
      textAlign: TextAlign.left,
      style: TextStyle(
        height: 1.171875,
        fontSize: 14.0,
        fontFamily: 'Montserrat',
        fontWeight: FontWeight.w400,
        color: Color.fromARGB(255, 0, 0, 0),

        /* letterSpacing: 0.0, */
      ),
    );
  }

  Widget _GeneratedIssuerINVOICEWidget(Invoice invoice, BuildContext context) {
    return Text(
      invoice.issuer, //Instance.getInstance().invoices["MyInvoices"][index].issuer,
      overflow: TextOverflow.visible,
      textAlign: TextAlign.left,
      style: TextStyle(
        height: 1.171875,
        fontSize: 10.0,
        fontFamily: 'Montserrat',
        fontWeight: FontWeight.w400,
        color: Color.fromARGB(255, 0, 0, 0),

        /* letterSpacing: 0.0, */
      ),
    );
  }

  Widget _GeneratedValueINVOICEWidget(Invoice invoice, BuildContext context) {
    double value = invoice.value;
    return Text(
      '$value €',
      overflow: TextOverflow.visible,
      textAlign: TextAlign.right,
      style: TextStyle(
        height: 1.171875,
        fontSize: 14.0,
        fontFamily: 'Montserrat',
        fontWeight: FontWeight.w500,
        color: Color.fromARGB(255, 0, 0, 0),

        /* letterSpacing: 0.0, */
      ),
    );
  }
}
