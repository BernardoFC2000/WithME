import 'package:flutter/material.dart';
import 'package:flutterapp/with_20me_203app/generatedaddnifoverlaywidget/GeneratedAddNIFOverlayWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedclothesscreenwidget/GeneratedClothesScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedhomeappliancesscreenwidget/GeneratedHomeAppliancesScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedhairstylerscreenwidget/GeneratedHairStylerScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedautomobilesscreenwidget/GeneratedAutomobilesScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatededucationscreenwidget/GeneratedEducationScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedhealthscreenwidget/GeneratedHealthScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedhousingscreenwidget/GeneratedHousingScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedfamilyscreenwidget/GeneratedFamilyScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedsettingsscreenwidget/GeneratedSettingsScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedaccountscreenwidget/GeneratedAccountScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatededitprofilescreenwidget/GeneratedEditProfileScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedavailablescreenwidget/GeneratedAvailableScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedunavailablescreenwidget/GeneratedUnavailableScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedaddinvoicepersonalscreenwidget/GeneratedAddInvoicePersonalScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedaddinvoicecompanyscreenwidget/GeneratedAddInvoiceCompanyScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedsucessfullyaddedscreenwidget/GeneratedSucessfullyaddedScreenWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedchangenifoverlaywidget/GeneratedChangeNIFOverlayWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedswitchwidget1/GeneratedSwitchWidget1.dart';
import 'package:flutterapp/with_20me_203app/generated_coverelementwidget/Generated_coverelementWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedswitcheswebsitewidget/GeneratedSwitcheswebsiteWidget.dart';
import 'package:flutterapp/with_20me_203app/generatedfavwidget2/GeneratedFavWidget2.dart';
import 'package:flutterapp/with_20me_203app/generatednotfavwidget8/GeneratedNotFavWidget8.dart';
import 'package:flutterapp/with_20me_203app/generatedstarwhitewidget1/GeneratedStarwhiteWidget1.dart';
import 'package:flutterapp/with_20me_203app/generatedcategoriesscreenwidget/GeneratedCategoriesScreenWidget.dart';
import 'package:flutterapp/backend/InvoiceModel.dart';

import 'with_20me_203app/generated_favouritesscreenwidget/GeneratedFavouritesScreenWidget.dart';
import 'with_20me_203app/generated_technologiesscreenwidget/GeneratedTechnologiesScreenWidget.dart';
import 'with_20me_203app/generatedmyinvoicesscreenwidget/GeneratedMyInvoicesScreenWidget.dart';
import 'with_20me_203app/generatedworteninvoicewidget/GeneratedWortenInvoiceWidget.dart';
import 'with_20me_203app/generatedsplashscreenwidget/GeneratedSplashScreenWidget.dart';
import 'package:flutterapp/invoice/SearchBar.dart';
import 'package:flutterapp/backend/database.dart';

void main() async {
  /*  
  WidgetsFlutterBinding.ensureInitialized();
  await MongoDatabase.connect();
  await MongoDatabase.insert(Invoice(
    issuer: "5015007930-IST",
    invoiceNumber: 3210062997,
    product: "Propinas",
    date: "2021-11-23",
    value: 630.0,
    warrantyTime: 0,
    category: "Education",
  ));
  await MongoDatabase.insert(Invoice(
    issuer: "5130046909-197-Farmacia",
    invoiceNumber: 62990,
    product: "Benuron",
    date: "2021-11-07",
    value: 9.99,
    warrantyTime: 0,
    category: "Health",
  ));*/
  runApp(With_20ME_203App());
}

class With_20ME_203App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedSplashScreenWidget',
      routes: {
        '/GeneratedAddNIFOverlayWidget': (context) => GeneratedAddNIFOverlayWidget(),
        '/GeneratedMyInvoicesScreenWidget': (context) => GeneratedMyInvoicesScreenWidget(),
        '/GeneratedClothesScreenWidget': (context) => GeneratedClothesScreenWidget(),
        '/GeneratedHomeAppliancesScreenWidget': (context) => GeneratedHomeAppliancesScreenWidget(),
        '/GeneratedHairStylerScreenWidget': (context) => GeneratedHairStylerScreenWidget(),
        '/GeneratedAutomobilesScreenWidget': (context) => GeneratedAutomobilesScreenWidget(),
        '/GeneratedEducationScreenWidget': (context) => GeneratedEducationScreenWidget(),
        '/GeneratedHealthScreenWidget': (context) => GeneratedHealthScreenWidget(),
        '/GeneratedHousingScreenWidget': (context) => GeneratedHousingScreenWidget(),
        '/GeneratedFamilyScreenWidget': (context) => GeneratedFamilyScreenWidget(),
        '/GeneratedSettingsScreenWidget': (context) => GeneratedSettingsScreenWidget(),
        '/GeneratedAccountScreenWidget': (context) => GeneratedAccountScreenWidget(),
        '/GeneratedEditProfileScreenWidget': (context) => GeneratedEditProfileScreenWidget(),
        '/GeneratedAvailableScreenWidget': (context) => GeneratedAvailableScreenWidget(),
        '/GeneratedUnavailableScreenWidget': (context) => GeneratedUnavailableScreenWidget(),
        '/GeneratedAddInvoicePersonalScreenWidget': (context) => GeneratedAddInvoicePersonalScreenWidget(),
        '/GeneratedAddInvoiceCompanyScreenWidget': (context) => GeneratedAddInvoiceCompanyScreenWidget(),
        '/GeneratedSucessfullyaddedScreenWidget': (context) => GeneratedSucessfullyaddedScreenWidget(),
        '/GeneratedChangeNIFOverlayWidget': (context) => GeneratedChangeNIFOverlayWidget(),
        '/GeneratedSwitchWidget1': (context) => GeneratedSwitchWidget1(),
        '/Generated_coverelementWidget': (context) => Generated_coverelementWidget(),
        '/GeneratedSwitcheswebsiteWidget': (context) => GeneratedSwitcheswebsiteWidget(),
        '/GeneratedFavWidget2': (context) => GeneratedFavWidget2(),
        '/GeneratedNotFavWidget8': (context) => GeneratedNotFavWidget8(),
        '/GeneratedStarwhiteWidget1': (context) => GeneratedStarwhiteWidget1(),
        '/GeneratedCategoriesScreenWidget': (context) => GeneratedCategoriesScreenWidget(),
        '/GeneratedFavoritesScreenWidget': (context) => GeneratedFavouritesScreenWidget(),
        '/GeneratedTechnologiesScreenWidget': (context) => GeneratedTechnologiesScreenWidget(),
        '/GeneratedWortenInvoiceScreenWidget': (context) => GeneratedWortenInvoiceScreenWidget(),
        '/GeneratedSplashScreenWidget': (context) => GeneratedSplashScreenWidget(),
        '/GeneratedSearchScreenWidget': (context) => SearchList()
      },
    );
  }
}
